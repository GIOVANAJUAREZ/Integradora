<?php
session_start();
if (isset($_SESSION['admin'])) {
    header("Location: mensajes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login Admin</title>
    <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
    <style>
        /* Simple form centering */
        body {
            display: flex; justify-content: center; align-items: center;
            height: 100vh; background: #FAF5F0; color: #5C4B3A;
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
        }
        form {
            background: #fff8f2; padding: 2rem; border-radius: 12px;
            box-shadow: 0 6px 12px rgba(92,75,58,0.1);
            width: 320px;
        }
        label, input {
            display: block; width: 100%; margin-bottom: 1rem;
        }
        input {
            padding: 0.7rem; border: 1.5px solid #D1C1B3;
            border-radius: 8px;
            font-size: 1rem;
            color: #5C4B3A;
        }
        input:focus {
            border-color: #B79972;
            outline: none;
        }
        button {
            background-color: #B79972;
            border: none; padding: 0.85rem; border-radius: 30px;
            color: #FAF5F0; font-weight: bold; cursor: pointer;
            width: 100%;
            font-size: 1.1rem;
        }
        button:hover {
            background-color: #926F49;
        }
        .error {
            color: red; margin-bottom: 1rem; text-align: center;
        }
    </style>
</head>
<body>
<?php
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include("../includes/db.php");
    $usuario = $_POST['usuario'] ?? '';
    $password = $_POST['password'] ?? '';

    $usuario = mysqli_real_escape_string($conn, $usuario);
    $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['admin'] = $usuario;
            header("Location: mensajes.php");
            exit();
        } else {
            $error = 'Usuario o contraseña incorrectos.';
        }
    } else {
        $error = 'Usuario o contraseña incorrectos.';
    }
}
?>

<form method="POST" novalidate>
    <h2 style="text-align:center; margin-bottom:1rem;">Ingreso Admin</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario" required autocomplete="off">

    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit">Entrar</button>
</form>

</body>
</html>
