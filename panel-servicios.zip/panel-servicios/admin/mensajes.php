<?php
include("../includes/db.php");
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}
include("../includes/db.php");
// Aquí deberías añadir autenticación para acceder a este panel

$query = "SELECT * FROM contactos ORDER BY fecha DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Mensajes de Contacto</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
  <style>
    table {
      border-collapse: collapse;
      width: 90%;
      margin: 2rem auto;
      background: #fff8f2;
      box-shadow: 0 6px 12px rgba(92,75,58,0.1);
      border-radius: 12px;
    }
    th, td {
      border: 1px solid #B79972;
      padding: 0.8rem 1rem;
      color: #5C4B3A;
      text-align: left;
    }
    th {
      background-color: #B79972;
      color: #FAF5F0;
    }
    tbody tr:hover {
      background-color: #D1C1B3;
    }
  </style>
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <h1 style="text-align:center; color:#B79972; margin-top:2rem;">Mensajes de Contacto</h1>
  <?php if ($result && mysqli_num_rows($result) > 0): ?>
  <table>
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Email</th>
        <th>Mensaje</th>
        <th>Fecha</th>
      </tr>
    </thead>
    <tbody>
      <?php while($row = mysqli_fetch_assoc($result)): ?>
      <tr>
        <td><?= htmlspecialchars($row['nombre']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= nl2br(htmlspecialchars($row['mensaje'])) ?></td>
        <td><?= date('d/m/Y H:i', strtotime($row['fecha'])) ?></td>
      </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
  <?php else: ?>
    <p style="text-align:center; margin-top:2rem;">No hay mensajes recibidos.</p>
  <?php endif; ?>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
