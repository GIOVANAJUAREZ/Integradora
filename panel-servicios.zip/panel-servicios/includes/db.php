<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "panel_servicios";
$port = 3308; // <--- Tu puerto personalizado

$conn = new mysqli($host, $user, $password, $database, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("❌ Error al conectar con la base de datos: " . $conn->connect_error);
}
?>
