<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Servicios Web</title>
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="/index.php">Inicio</a></li>
                <li><a href="/panel-servicios/pages/servicios.php">Servicios</a></li>
                <li><a href="/panel-servicios/pages/personalizados.php">Personalizados</a></li>
                <li><a href="/panel-servicios/pages/apis.php">APIs</a></li>
                <li><a href="/panel-servicios/pages/carrito.php">Carrito</a></li>
                <li><a href="/panel-servicios/pages/contacto.php">Contacto</a></li>
            </ul>
        </nav>
    </header>
    <main>
