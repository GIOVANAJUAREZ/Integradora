<?php
session_start();
include("../includes/db.php"); // conexión a la base de datos
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Servicios Disponibles</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
  <style>
    .intro-servicios {
      max-width: 900px;
      margin: 2rem auto;
      padding: 1rem 2rem;
      text-align: center;
      background-color: #fff8f2;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(92, 75, 58, 0.1);
    }
    .intro-servicios img {
      width: 60px;
      margin-bottom: 1rem;
    }
    .intro-servicios p {
      font-size: 1.1rem;
      color: #7E6B57;
    }
    .servicio-card {
      animation: fadeInUp 0.6s ease;
    }
    @keyframes fadeInUp {
      from {
        transform: translateY(20px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
    .cta-final {
      text-align: center;
      margin: 4rem 0 2rem;
    }
    .cta-final p {
      font-size: 1.2rem;
      color: #5C4B3A;
      margin-bottom: 1rem;
    }
    .btn-primary {
      background-color: #B79972;
      color: #FAF5F0;
      border: none;
      padding: 0.75rem 1.5rem;
      border-radius: 30px;
      font-weight: 700;
      cursor: pointer;
      font-size: 1rem;
      transition: background-color 0.3s ease;
      display: inline-block;
      text-decoration: none;
      width: 100%;
      margin-top: 1rem;
    }
    .btn-primary:hover {
      background-color: #926F49;
    }
  </style>
</head>
<body>

<?php include("../includes/header.php"); ?>

<main>
  <?php if (!empty($_GET['msg'])): ?>
    <p style="text-align:center; background:#B79972; color:#FAF5F0; padding:10px; border-radius:8px; font-weight:700; max-width:600px; margin: 1rem auto;">
      <?= htmlspecialchars($_GET['msg']) ?>
    </p>
  <?php endif; ?>

  <!-- Hero -->
  <section class="hero-section">
    <h1>Servicios Disponibles</h1>
    <p>Explora nuestros servicios diseñados para impulsar tu proyecto web.</p>
  </section>

  <!-- Introducción -->
  <section class="intro-servicios" aria-label="Introducción">
    <img src="/panel-servicios/assets/icons/idea.svg" alt="Icono de ideas">
    <p>
      En nuestro panel encontrarás soluciones diseñadas para desarrolladores, emprendedores y empresas. 
      Todos nuestros servicios pueden adaptarse a tus necesidades.
    </p>
  </section>

  <!-- Catálogo -->
  <section id="servicios" aria-labelledby="servicios-title">
    <h2 id="servicios-title">Catálogo de Servicios</h2>
    <div class="servicios-grid">

<?php
$query = "SELECT * FROM servicios";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0):
  while ($row = mysqli_fetch_assoc($result)):
    $id = $row['id'];
    $titulo = $row['titulo'] ?? 'Sin título';
    $descripcion = $row['descripcion'] ?? 'Sin descripción';
    $icono = $row['icono'] ?? '/panel-servicios/assets/icons/default.svg';
?>
      <article class="servicio-card" aria-label="<?= htmlspecialchars($titulo) ?>">
        <img src="<?= htmlspecialchars($icono) ?>" alt="Icono de <?= htmlspecialchars($titulo) ?>" loading="lazy">
        <h3><?= htmlspecialchars($titulo) ?></h3>
        <p><?= htmlspecialchars($descripcion) ?></p>

        <?php if (isset($_SESSION['user_id'])): ?>
          <form method="POST" action="/panel-servicios/form/agregar-carrito.php">
            <input type="hidden" name="servicio_id" value="<?= $id ?>">
            <button type="submit" class="btn-primary">Agregar al carrito</button>
          </form>
        <?php else: ?>
          <a href="/panel-servicios/pages/login.php" class="btn-primary">Inicia sesión para agregar</a>
        <?php endif; ?>
      </article>
<?php
  endwhile;
else:
?>
      <p style="text-align:center; color:#7E6B57;">No hay servicios disponibles por el momento.</p>
<?php endif; ?>

    </div>
  </section>

  <!-- CTA -->
  <section class="cta-final" aria-label="Más información">
    <p>¿Necesitas un servicio personalizado o una API específica para tu empresa?</p>
    <a href="/panel-servicios/pages/contacto.php" class="btn-primary">Contáctanos</a>
  </section>

  <!-- Ventajas -->
  <section aria-label="Ventajas" style="margin-top: 4rem;">
    <h2>¿Por qué elegir nuestros servicios?</h2>
    <div class="servicios-grid">
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/seguro.svg" alt="Seguro" loading="lazy">
        <h3>Seguridad garantizada</h3>
        <p>Tus datos y proyectos están protegidos con protocolos de seguridad avanzados.</p>
      </div>
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/rapido.svg" alt="Rápido" loading="lazy">
        <h3>Velocidad y eficiencia</h3>
        <p>Nuestros servidores y APIs están optimizados para ofrecer el mejor rendimiento.</p>
      </div>
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/soporte.svg" alt="Soporte" loading="lazy">
        <h3>Soporte personalizado</h3>
        <p>Atención directa y humana por parte de nuestro equipo de expertos.</p>
      </div>
    </div>
  </section>

  <!-- Categorías -->
  <section aria-label="Tipos de servicios" style="margin-top: 4rem;">
    <h2>Categorías de Servicios</h2>
    <div class="servicios-grid">
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/api.svg" alt="APIs" loading="lazy">
        <h3>APIs & Conectores</h3>
        <p>Integraciones eficientes para conectar tus apps con plataformas externas.</p>
      </div>
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/web.svg" alt="Web" loading="lazy">
        <h3>Desarrollo Web</h3>
        <p>Landing pages, sitios informativos y paneles administrativos responsivos.</p>
      </div>
      <div class="servicio-card">
        <img src="/panel-servicios/assets/icons/mantenimiento.svg" alt="Mantenimiento" loading="lazy">
        <h3>Mantenimiento y soporte</h3>
        <p>Te ayudamos a mantener tu sistema estable, actualizado y funcional 24/7.</p>
      </div>
    </div>
  </section>

  <!-- Testimonios -->
  <section aria-label="Testimonios" style="margin-top: 4rem;">
    <h2>Lo que opinan nuestros clientes</h2>
    <div class="servicios-grid">
      <div class="servicio-card">
        <p><em>"Gracias al equipo de soporte, pude lanzar mi tienda en menos de una semana. ¡Increíble!"</em></p>
        <p><strong>- Ana G., emprendedora</strong></p>
      </div>
      <div class="servicio-card">
        <p><em>"La API personalizada que me entregaron funciona perfecto y me ahorró semanas de trabajo."</em></p>
        <p><strong>- Luis R., desarrollador freelance</strong></p>
      </div>
      <div class="servicio-card">
        <p><em>"Nunca había recibido un trato tan cercano en temas técnicos. ¡Muy recomendados!"</em></p>
        <p><strong>- Mariana V., consultora digital</strong></p>
      </div>
    </div>
  </section>

  <!-- Garantía -->
  <section class="cta-final" aria-label="Garantía">
    <p>Estamos tan seguros de la calidad de nuestro trabajo que ofrecemos garantía total en cada servicio.</p>
    <a href="/panel-servicios/pages/contacto.php" class="btn-primary">Solicitar más información</a>
  </section>

</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
