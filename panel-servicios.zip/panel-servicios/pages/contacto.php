<?php include("../includes/db.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Contacto</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
</head>
<body>

<?php include("../includes/header.php"); ?>

<main>
  <section class="hero-section">
    <h1>Contacto</h1>
    <p>¿Tienes dudas o quieres un servicio personalizado? Contáctanos directamente.</p>
  </section>

  <section id="contacto">
    <h2>Envíanos tu mensaje</h2>

    <form action="/panel-servicios/form/contacto.php" method="POST" class="form-personalizado">
      <label for="nombre">Nombre completo:</label>
      <input type="text" id="nombre" name="nombre" required placeholder="Ej. Juan Pérez">

      <label for="email">Correo electrónico:</label>
      <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com">

      <label for="mensaje">Mensaje:</label>
      <textarea id="mensaje" name="mensaje" rows="5" required placeholder="Escribe tu mensaje aquí..."></textarea>

      <button type="submit">Enviar</button>
    </form>
  </section>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
