<?php
include("../includes/db.php"); // conexión a la base de datos
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Servicios Personalizados</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
  <style>
    .fecha-publicacion {
      font-size: 0.9rem;
      color: #A08972;
      margin-top: 0.5rem;
    }

    .beneficios-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 2rem;
      margin-top: 3rem;
    }

    .beneficio {
      background-color: #fff8f2;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(92, 75, 58, 0.1);
      padding: 1.5rem;
      width: 280px;
      text-align: center;
    }

    .beneficio img {
      width: 50px;
      margin-bottom: 1rem;
    }

    .form-personalizado {
      max-width: 600px;
      margin: 4rem auto 2rem;
      background: #fff8f2;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(92, 75, 58, 0.1);
    }

    .form-personalizado h3 {
      text-align: center;
      color: #B79972;
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>

<?php include("../includes/header.php"); ?>

<main>
  <!-- Hero -->
  <section class="hero-section">
    <h1>Servicios Personalizados</h1>
    <p>Solicita soluciones únicas y adaptadas a tus necesidades.</p>
    <a href="#formulario" class="btn-primary">Solicitar servicio</a>
  </section>

  <!-- Beneficios -->
  <section class="intro-servicios" style="margin-top: 2rem;">
    <img src="/panel-servicios/assets/icons/custom.svg" alt="Icono personalizado">
    <p>¿Por qué elegir un servicio personalizado con nosotros? Aquí algunas razones:</p>
    <div class="beneficios-grid">
      <div class="beneficio">
        <img src="/panel-servicios/assets/icons/flexibilidad.svg" alt="Flexibilidad">
        <h4>100% a medida</h4>
        <p>Diseñamos exactamente lo que necesitas, sin plantillas ni limitaciones.</p>
      </div>
      <div class="beneficio">
        <img src="/panel-servicios/assets/icons/soporte.svg" alt="Soporte técnico">
        <h4>Soporte directo</h4>
        <p>Acompañamiento en cada etapa: desde la idea hasta la entrega final.</p>
      </div>
      <div class="beneficio">
        <img src="/panel-servicios/assets/icons/seguro.svg" alt="Seguridad">
        <h4>Garantía y seguridad</h4>
        <p>Te damos garantía de calidad, rendimiento y protección de tus datos.</p>
      </div>
    </div>
  </section>

  <!-- Servicios desde BD -->
  <section id="catalogo">
    <h2>Proyectos Personalizados Realizados</h2>
    <div class="servicios-grid">
      <?php
      $query = "SELECT * FROM personalizados ORDER BY fecha DESC";
      $result = mysqli_query($conn, $query);

      if ($result && mysqli_num_rows($result) > 0):
        while ($row = mysqli_fetch_assoc($result)):
          $nombre = $row['nombre'] ?? 'Sin nombre';
          $descripcion = $row['descripcion'] ?? 'Sin descripción';
          $fecha = $row['fecha'] ?? '';
      ?>
        <article class="servicio-card">
          <img src="/panel-servicios/assets/icons/project.svg" alt="Proyecto <?= htmlspecialchars($nombre) ?>" loading="lazy">
          <h3><?= htmlspecialchars($nombre) ?></h3>
          <p><?= htmlspecialchars($descripcion) ?></p>
          <?php if ($fecha): ?>
            <p class="fecha-publicacion">Publicado el <?= date('d/m/Y', strtotime($fecha)) ?></p>
          <?php endif; ?>
        </article>
      <?php
        endwhile;
      else:
        echo '<p style="text-align:center; color:#7E6B57;">No hay proyectos personalizados registrados todavía.</p>';
      endif;
      ?>
    </div>
  </section>

  <!-- Formulario de solicitud -->
  <section id="formulario" class="form-personalizado">
    <h3>Solicita tu servicio personalizado</h3>
    <form action="/panel-servicios/form/solicitar.php" method="POST">
      <label for="cliente_nombre">Tu nombre completo:</label>
      <input type="text" id="cliente_nombre" name="cliente_nombre" required placeholder="Ej. Juan Pérez">

      <label for="cliente_email">Correo electrónico:</label>
      <input type="email" id="cliente_email" name="cliente_email" required placeholder="Ej. ejemplo@correo.com">

      <label for="cliente_necesidad">¿Qué necesitas?</label>
      <textarea id="cliente_necesidad" name="cliente_necesidad" rows="5" required placeholder="Describe brevemente tu proyecto o necesidad..."></textarea>

      <button type="submit">Enviar solicitud</button>
    </form>
  </section>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
