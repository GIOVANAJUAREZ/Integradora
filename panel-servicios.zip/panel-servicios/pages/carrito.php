<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php?msg=Debes iniciar sesión para ver el carrito");
  exit();
}

$user_id = intval($_SESSION['user_id']);

$query = "SELECT s.*, c.fecha_agregado FROM carrito c
          JOIN servicios s ON c.servicio_id = s.id
          WHERE c.user_id = $user_id";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Mi Carrito</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <h1>Tu Carrito de Servicios</h1>

  <?php if ($result && mysqli_num_rows($result) > 0): ?>
    <ul style="max-width: 800px; margin: 2rem auto; list-style: none; padding: 0;">
      <?php while ($serv = mysqli_fetch_assoc($result)): ?>
        <li style="background: #fff8f2; margin-bottom: 1rem; padding: 1rem; border-radius: 12px; box-shadow: 0 6px 12px rgba(92,75,58,0.1);">
          <h3><?= htmlspecialchars($serv['titulo']) ?></h3>
          <p><?= htmlspecialchars($serv['descripcion']) ?></p>
          <small>Agregado el <?= date('d/m/Y H:i', strtotime($serv['fecha_agregado'])) ?></small>
        </li>
      <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <p style="text-align:center; color:#7E6B57;">Tu carrito está vacío.</p>
  <?php endif; ?>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
