<?php
session_start();
include("../includes/db.php");

// Capturamos mensaje si hay (éxito/error al contratar)
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>APIs Disponibles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
    <style>
      /* Estilos específicos para esta página */
      .apis-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 2rem;
        justify-content: center;
        margin: 2rem 1rem;
      }
      .api-card {
        background-color: #fff8f2;
        width: 320px;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 6px 12px rgba(92,75,58,0.1);
        text-align: center;
        color: #5C4B3A;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }
      .api-card h3 {
        font-size: 1.4rem;
        margin-bottom: 0.5rem;
        color: #B79972;
      }
      .api-card p {
        flex-grow: 1;
        font-size: 1rem;
        margin-bottom: 1rem;
        color: #7E6B57;
      }
      .api-buttons {
        display: flex;
        justify-content: center;
        gap: 1rem;
      }
      .api-buttons a, .api-buttons form button {
        flex: 1;
        padding: 0.6rem 1rem;
        border-radius: 30px;
        font-weight: 700;
        cursor: pointer;
        border: none;
        transition: background-color 0.3s ease;
        text-decoration: none;
        color: #FAF5F0;
        font-size: 1rem;
      }
      .btn-doc {
        background-color: #D1C1B3;
      }
      .btn-doc:hover {
        background-color: #B79972;
      }
      .btn-contratar {
        background-color: #B79972;
      }
      .btn-contratar:hover {
        background-color: #926F49;
      }
      /* Mensaje de alerta */
      .alert-msg {
        max-width: 600px;
        margin: 1rem auto;
        padding: 1rem;
        background-color: #B79972;
        color: #FAF5F0;
        border-radius: 8px;
        text-align: center;
        font-weight: 700;
      }
      @media (max-width: 768px) {
        .apis-grid {
          flex-direction: column;
          align-items: center;
        }
        .api-card {
          width: 90%;
        }
      }
    </style>
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <section class="hero-section" aria-label="APIs disponibles">
    <h1>Integración de APIs</h1>
    <p>Explora nuestras APIs para potenciar tus proyectos con datos y funcionalidades de última generación.</p>
  </section>

  <?php if ($msg): ?>
    <div class="alert-msg"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <section class="apis-grid" aria-label="Lista de APIs disponibles">

  <?php
  $query = "SELECT * FROM apis ORDER BY nombre ASC";
  $result = mysqli_query($conn, $query);

  if ($result && mysqli_num_rows($result) > 0):
    while ($api = mysqli_fetch_assoc($result)):
      $id = $api['id'];
      $nombre = $api['nombre'];
      $descripcion = $api['descripcion'];
      $url = $api['url'];
  ?>
    <article class="api-card" aria-labelledby="api-title-<?= $id ?>">
      <h3 id="api-title-<?= $id ?>"><?= htmlspecialchars($nombre) ?></h3>
      <p><?= htmlspecialchars($descripcion) ?></p>
      <div class="api-buttons">
        <a href="<?= htmlspecialchars($url) ?>" target="_blank" class="btn-doc" aria-label="Ver documentación de <?= htmlspecialchars($nombre) ?>">Documentación</a>

        <?php if (isset($_SESSION['user_id'])): ?>
          <form method="POST" action="/panel-servicios/form/contratar-api.php" style="margin:0;">
            <input type="hidden" name="api_id" value="<?= $id ?>">
            <button type="submit" class="btn-contratar" aria-label="Contratar API <?= htmlspecialchars($nombre) ?>">Contratar</button>
          </form>
        <?php else: ?>
          <a href="/panel-servicios/pages/login.php" class="btn-contratar" style="display:inline-block; text-align:center;">Inicia sesión para contratar</a>
        <?php endif; ?>

      </div>
    </article>
  <?php
    endwhile;
  else:
  ?>
    <p style="text-align:center; color:#7E6B57;">No hay APIs disponibles por el momento.</p>
  <?php endif; ?>

  </section>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
