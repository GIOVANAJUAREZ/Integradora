<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include("../includes/db.php");

$sql = "SELECT * FROM servicios";
$result = $conn->query($sql);

$servicios = [];

while ($row = $result->fetch_assoc()) {
    $servicios[] = [
        'id' => $row['id'],
        'nombre' => $row['nombre'],
        'descripcion' => $row['descripcion'],
        'precio' => $row['precio']
    ];
}

echo json_encode($servicios, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
