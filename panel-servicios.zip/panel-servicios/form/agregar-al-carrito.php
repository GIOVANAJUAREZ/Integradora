<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para agregar servicios al carrito");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_SESSION['user_id']);
    $servicio_id = intval($_POST['servicio_id']);

    // Verificar que el servicio existe
    $query = "SELECT * FROM servicios WHERE id = $servicio_id";
    $result = mysqli_query($conn, $query);
    if (!$result || mysqli_num_rows($result) === 0) {
        header("Location: ../pages/servicios.php?msg=Servicio no encontrado");
        exit();
    }

    // Verificar si ya está en el carrito
    $check = "SELECT * FROM carrito WHERE user_id = $user_id AND servicio_id = $servicio_id";
    $resCheck = mysqli_query($conn, $check);
    if ($resCheck && mysqli_num_rows($resCheck) > 0) {
        header("Location: ../pages/servicios.php?msg=Este servicio ya está en tu carrito");
        exit();
    }

    // Insertar en carrito
    $insert = "INSERT INTO carrito (user_id, servicio_id) VALUES ($user_id, $servicio_id)";
    if (mysqli_query($conn, $insert)) {
        header("Location: ../pages/servicios.php?msg=Servicio agregado al carrito");
    } else {
        header("Location: ../pages/servicios.php?msg=Error al agregar el servicio");
    }
} else {
    header("Location: ../pages/servicios.php");
}
