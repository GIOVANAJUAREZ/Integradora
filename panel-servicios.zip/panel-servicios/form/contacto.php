<?php
include("../includes/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $mensaje = mysqli_real_escape_string($conn, $_POST['mensaje']);

  $query = "INSERT INTO contactos (nombre, email, mensaje) VALUES ('$nombre', '$email', '$mensaje')";
  $result = mysqli_query($conn, $query);

  if ($result) {
    // Enviar correo a admin
    $to = "tu-email@dominio.com";  // Cambia por tu email real
    $subject = "Nuevo mensaje de contacto";
    $body = "Has recibido un nuevo mensaje de contacto:\n\n";
    $body .= "Nombre: $nombre\n";
    $body .= "Correo: $email\n";
    $body .= "Mensaje:\n$mensaje\n";

    $headers = "From: no-reply@tusitio.com\r\n";
    $headers .= "Reply-To: $email\r\n";

    mail($to, $subject, $body, $headers);

    echo "<script>alert('Mensaje enviado correctamente.'); window.location.href = '../pages/contacto.php';</script>";
  } else {
    echo "<script>alert('Error al enviar el mensaje.'); window.history.back();</script>";
  }
}
?>
