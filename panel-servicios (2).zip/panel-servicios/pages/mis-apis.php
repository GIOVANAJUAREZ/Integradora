<?php
session_start();
include("../includes/db.php");

// Verificar sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Debes iniciar sesión para ver tus APIs");
    exit();
}

$user_id = $_SESSION['user_id'];

// Consulta APIs contratadas
$query = "SELECT a.* FROM apis a
          INNER JOIN contratos_api c ON a.id = c.api_id
          WHERE c.user_id = $user_id
          ORDER BY c.fecha DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Mis APIs Contratadas</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <section class="hero-section">
    <h1>Mis APIs Contratadas</h1>
    <p>Estas son las APIs que has contratado y puedes gestionar.</p>
  </section>

  <?php if ($result && mysqli_num_rows($result) > 0): ?>
    <section class="apis-grid" aria-label="APIs contratadas por el usuario">
    <?php while ($api = mysqli_fetch_assoc($result)): ?>
      <article class="api-card" aria-labelledby="api-title-<?= $api['id'] ?>">
        <h3 id="api-title-<?= $api['id'] ?>"><?= htmlspecialchars($api['nombre']) ?></h3>
        <p><?= htmlspecialchars($api['descripcion']) ?></p>
        <a href="<?= htmlspecialchars($api['url']) ?>" target="_blank" class="btn-doc">Documentación</a>
      </article>
    <?php endwhile; ?>
    </section>
  <?php else: ?>
    <p style="text-align:center; margin: 2rem; color:#7E6B57;">No has contratado ninguna API aún.</p>
  <?php endif; ?>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
