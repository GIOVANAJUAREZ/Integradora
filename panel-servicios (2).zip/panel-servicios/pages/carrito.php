<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para ver el carrito");
    exit();
}

$user_id = intval($_SESSION['user_id']);
$msg = $_GET['msg'] ?? '';

// Eliminar producto del carrito si se recibe la petición
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['carrito_id'])) {
    $carrito_id = intval($_POST['carrito_id']);
    $delete = mysqli_query($conn, "DELETE FROM carrito WHERE id = $carrito_id AND user_id = $user_id");
    if ($delete) {
        header("Location: carrito.php?msg=Producto eliminado del carrito");
        exit();
    } else {
        $msg = "Error al eliminar el producto";
    }
}

// Obtener items del carrito con detalle según tipo
$query = "SELECT * FROM carrito WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

$items = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $carrito_id = $row['id'];
        $tipo = $row['tipo'];  // Debe existir este campo en la tabla carrito
        $item_id = $row['item_id'];

        // Según tipo, hacer consulta para obtener info
        if ($tipo === 'api') {
            $res = mysqli_query($conn, "SELECT nombre, descripcion, url FROM apis WHERE id = $item_id LIMIT 1");
        } elseif ($tipo === 'servicio') {
            $res = mysqli_query($conn, "SELECT nombre, descripcion, url FROM servicios WHERE id = $item_id LIMIT 1");
        } elseif ($tipo === 'personalizado') {
            $res = mysqli_query($conn, "SELECT nombre, descripcion, url FROM personalizados WHERE id = $item_id LIMIT 1");
        } else {
            $res = false;
        }

        if ($res && mysqli_num_rows($res) > 0) {
            $info = mysqli_fetch_assoc($res);
            $items[] = [
                'carrito_id' => $carrito_id,
                'nombre' => $info['nombre'],
                'descripcion' => $info['descripcion'],
                'url' => $info['url'],
                'tipo' => $tipo
            ];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Mi Carrito</title>
  <!-- ... tu CSS aquí ... -->
</head>
<body>
  <!-- Sidebar y demás -->

  <main>
    <h1>Mi Carrito</h1>

    <?php if ($msg): ?>
      <div class="toast"><?= htmlspecialchars($msg) ?></div>
      <script>
        setTimeout(() => {
          const toast = document.querySelector('.toast');
          if (toast) toast.remove();
        }, 3500);
      </script>
    <?php endif; ?>

    <?php if (!empty($items)): ?>
      <table>
        <thead>
          <tr>
            <th>Tipo</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>URL</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td><?= htmlspecialchars(ucfirst($item['tipo'])) ?></td>
              <td><?= htmlspecialchars($item['nombre']) ?></td>
              <td><?= htmlspecialchars($item['descripcion']) ?></td>
              <td><a href="<?= htmlspecialchars($item['url']) ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($item['url']) ?></a></td>
              <td>
                <form method="POST" style="margin:0;">
                  <input type="hidden" name="carrito_id" value="<?= intval($item['carrito_id']) ?>">
                  <button type="submit" class="delete-btn" aria-label="Eliminar del carrito">Eliminar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p class="empty-msg">Tu carrito está vacío.</p>
    <?php endif; ?>
  </main>
</body>
</html>
