<?php
session_start();
include("../includes/db.php");

$limit = 4;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$busqueda = isset($_GET['buscar']) ? mysqli_real_escape_string($conn, $_GET['buscar']) : '';
$msg = $_GET['msg'] ?? '';

$whereClause = $busqueda ? "WHERE nombre LIKE '%$busqueda%'" : '';
$totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM personalizados $whereClause");
$totalRow = mysqli_fetch_assoc($totalQuery);
$totalPersonalizados = $totalRow['total'];
$totalPages = ceil($totalPersonalizados / $limit);

$query = "SELECT * FROM personalizados $whereClause LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Servicios Personalizados</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
=  <style>
    /* Reset */
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #121212;
      color: #e0e0e0;
      display: flex;
      min-height: 100vh;
    }
    /* Sidebar */
    header.sidebar {
      background-color: #1a1a1a;
      width: 220px;
      min-height: 100vh;
      padding: 2rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      box-shadow: 2px 0 5px rgba(0,0,0,0.7);
      z-index: 1000;
    }
    header.sidebar nav ul {
      list-style: none;
      padding: 0;
      margin: 0;
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }
    header.sidebar nav ul li a {
      color: #e0e0e0;
      text-decoration: none;
      font-weight: 600;
      font-size: 1rem;
      padding: 0.5rem;
      border-radius: 5px;
      transition: background-color 0.3s ease, padding-left 0.3s ease;
      display: block;
    }
    header.sidebar nav ul li a:hover,
    header.sidebar nav ul li a.active {
      background-color: #333;
      padding-left: 1rem;
    }
    /* Main content */
    main.main-content {
      margin-left: 220px;
      padding: 2rem;
      flex: 1;
      background-color: #1e1e1e;
      min-height: 100vh;
    }
    /* Buscador */
    .buscador {
      text-align: center;
      margin-bottom: 2rem;
    }
    .buscador input {
      padding: 0.5rem;
      border-radius: 6px;
      border: 1px solid #444;
      background: #222;
      color: #eee;
      width: 250px;
    }
    .buscador button {
      padding: 0.5rem 1rem;
      border: none;
      background: #444;
      color: #fff;
      border-radius: 6px;
      cursor: pointer;
    }
    /* Grid 2 columnas x 2 filas */
    .personalizados-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      grid-template-rows: repeat(2, auto);
      gap: 1.5rem 2rem;
      max-width: 700px;
      margin: 0 auto;
    }
    /* Tarjetas */
    .personalizado-card {
      background: #222;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 0 8px #000;
      color: #eee;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .personalizado-card h3 {
      margin-top: 0;
      margin-bottom: 0.5rem;
      font-size: 1.3rem;
      color: #fff;
    }
    .personalizado-card p {
      font-size: 1rem;
      color: #ccc;
      flex-grow: 1;
    }
    .personalizado-card strong {
      color: #ddd;
      margin-top: 1rem;
      font-weight: 600;
    }
    /* Paginación */
    .pagination {
      margin-top: 2.5rem;
      display: flex;
      justify-content: center;
      gap: 8px;
      flex-wrap: wrap;
    }
    .pagination a,
    .pagination span {
      padding: 0.4rem 0.9rem;
      border: 1px solid #555;
      border-radius: 6px;
      color: #eee;
      text-decoration: none;
      min-width: 30px;
      text-align: center;
    }
    .pagination .active {
      background: #666;
      color: #fff;
    }
    /* Mensaje */
    #toast-msg {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: #444;
      color: white;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      z-index: 9999;
      animation: fadein 0.5s, fadeout 0.5s 3s;
    }
    @keyframes fadein {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    @keyframes fadeout {
      from {
        opacity: 1;
      }
      to {
        opacity: 0;
      }
    }

    /* Responsive */
    @media (max-width: 600px) {
      .personalizados-grid {
        grid-template-columns: 1fr;
        grid-template-rows: auto;
        max-width: 90%;
      }
      main.main-content {
        margin-left: 0;
        padding: 1rem;
      }
      header.sidebar {
        position: relative;
        width: 100%;
        min-height: auto;
        padding: 1rem 0;
        box-shadow: none;
        display: flex;
        justify-content: center;
      }
      header.sidebar nav ul {
        flex-direction: row;
        gap: 1rem;
      }
      header.sidebar nav ul li a {
        padding: 0.5rem 0.75rem;
      }
    }
    .personalizados-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-top: 2rem;
}

.personalizado-card {
  background-color: #2a2a2a;
  padding: 1.5rem;
  border-radius: 12px;
  box-shadow: 0 6px 12px rgba(0,0,0,0.2);
  transition: transform 0.3s ease;
  text-align: center;
}

.personalizado-card:hover {
  transform: translateY(-5px);
}

.personalizado-card h3 {
  color: #fff;
  margin-bottom: 0.5rem;
}

.personalizado-card p {
  color: #ccc;
  font-size: 0.95rem;
  margin: 0.4rem 0;
}

.btn-primary {
  margin-top: 1rem;
  background-color: #2a2a2a;
  color: #FAF5F0;
  padding: 0.6rem 1.2rem;
  border: none;
  border-radius: 30px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.btn-primary:hover {
  background-color: #2a2a2a;
}

.btn-primary[disabled] {
  background-color: #444;
  color: #aaa;
  cursor: not-allowed;
}
    /* Sidebar */
    aside.sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100vh;
      background-color: #1a1a1a;
      padding: 2rem 1rem;
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
      box-shadow: 2px 0 8px rgba(0,0,0,0.8);
      z-index: 1000;
    }

    aside.sidebar h2 {
      color: #fff;
      text-align: center;
      margin-bottom: 2rem;
      font-weight: 700;
      font-size: 1.5rem;
    }

    aside.sidebar nav a {
      color: #bbb;
      text-decoration: none;
      padding: 0.6rem 1rem;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.3s ease, color 0.3s ease;
      display: block;
    }

    aside.sidebar nav a:hover,
    aside.sidebar nav a.active {
      background-color: #333;
      color: #fff;
      padding-left: 1.2rem;
    }
  </style>
</head>
<body>

  <aside class="sidebar">
    <h2>Menú</h2>
    <nav>
      <a href="/panel-servicios/index.php">Inicio</a>
      <a href="/panel-servicios/pages/servicios.php" class="active">Servicios</a>
      <a href="/panel-servicios/pages/personalizados.php">Personalizados</a>
      <a href="/panel-servicios/pages/apis.php">APIs</a>
      <a href="/panel-servicios/pages/carrito.php">Carrito</a>
      <a href="/panel-servicios/pages/contacto.php">Contacto</a>
    </nav>
  </aside>


<main class="main-content">

  <h1 style="text-align:center;">Servicios Personalizados</h1>

  <div class="buscador">
    <form method="GET" style="background-color: #1a1a1a;">
      <input type="text" name="buscar" placeholder="Buscar servicio personalizado..." value="<?= htmlspecialchars($busqueda) ?>" />
      <button type="submit">Buscar</button>
    </form>
  </div>

  <div class="personalizados-grid">
    <?php if ($result && mysqli_num_rows($result) > 0): ?>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="personalizado-card">
          <h3><?= htmlspecialchars($row['nombre']) ?></h3>
          <p><?= htmlspecialchars($row['descripcion']) ?></p>
          <p><strong>Precio:</strong> $<?= isset($row['precio']) ? number_format($row['precio'], 2) : '0.00' ?></p>

          <?php
          $servicioID = $row['id'];
          $yaEnCarrito = false;

          if (isset($_SESSION['user_id'])) {
              $uid = intval($_SESSION['user_id']);
              $check = mysqli_query($conn, "SELECT 1 FROM carrito WHERE user_id = $uid AND servicio_id = $servicioID");
              if (mysqli_num_rows($check) > 0) {
                  $yaEnCarrito = true;
              }
          }
          ?>

          <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($yaEnCarrito): ?>
              <button class="btn-primary" disabled>Ya en carrito</button>
            <?php else: ?>
              <form method="POST" style="background-color: #2a2a2a; margin-top: -10px;" action="/panel-servicios/form/agregar-al-carrito.php" >
                <input type="hidden" name="servicio_id" value="<?= $servicioID ?>">
                <input type="hidden" name="tipo" value="personalizado">
                <button type="submit"style="background-color:rgb(64, 63, 63);" class="btn-primary">Agregar al carrito</button>
              </form>
            <?php endif; ?>
          <?php else: ?>
            <a href="/panel-servicios/pages/login.php" class="btn-primary">Inicia sesión</a>
          <?php endif; ?>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center;">No se encontraron servicios personalizados.</p>
    <?php endif; ?>
  </div>

  <div class="pagination">
    <?php if ($page > 1): ?>
      <a href="?page=<?= $page - 1 ?>&buscar=<?= urlencode($busqueda) ?>">&laquo; Anterior</a>
    <?php endif; ?>
    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
      <?php if ($i == $page): ?>
        <span class="active"><?= $i ?></span>
      <?php else: ?>
        <a href="?page=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
      <?php endif; ?>
    <?php endfor; ?>
    <?php if ($page < $totalPages): ?>
      <a href="?page=<?= $page + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente &raquo;</a>
    <?php endif; ?>
  </div>

</main>

<?php if ($msg): ?>
  <div id="toast-msg"><?= htmlspecialchars($msg) ?></div>
  <script>
    setTimeout(() => {
      const toast = document.getElementById('toast-msg');
      if (toast) toast.remove();
    }, 3500);
  </script>
<?php endif; ?>

</body>
</html>
