<?php
session_start();
include("../includes/db.php");

$limit = 8;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;
$busqueda = isset($_GET['buscar']) ? mysqli_real_escape_string($conn, $_GET['buscar']) : '';
$msg = $_GET['msg'] ?? '';

// Servicios agregados al carrito
$serviciosAgregados = [];
if (isset($_SESSION['user_id'])) {
    $uid = intval($_SESSION['user_id']);
    $carritoQuery = mysqli_query($conn, "SELECT servicio_id FROM carrito WHERE user_id = $uid");
    while ($car = mysqli_fetch_assoc($carritoQuery)) {
        $serviciosAgregados[] = $car['servicio_id'];
    }
}

$whereClause = $busqueda ? "WHERE nombre LIKE '%$busqueda%'" : '';
$totalQuery = mysqli_query($conn, "SELECT COUNT(*) AS total FROM servicios $whereClause");
$totalRow = mysqli_fetch_assoc($totalQuery);
$totalServicios = $totalRow['total'];
$totalPages = ceil($totalServicios / $limit);

$query = "SELECT * FROM servicios $whereClause LIMIT $limit OFFSET $offset";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Servicios Disponibles</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    /* Reset */
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #121212;
      color: #e0e0e0;
      display: flex;
      min-height: 100vh;
    }

    /* Sidebar */
    aside.sidebar {
      position: fixed;
      top: 0;
      left: 0;
      width: 220px;
      height: 100vh;
      background-color: #1a1a1a;
      padding: 2rem 1rem;
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
      box-shadow: 2px 0 8px rgba(0,0,0,0.8);
      z-index: 1000;
    }

    aside.sidebar h2 {
      color: #fff;
      text-align: center;
      margin-bottom: 2rem;
      font-weight: 700;
      font-size: 1.5rem;
    }

    aside.sidebar nav a {
      color: #bbb;
      text-decoration: none;
      padding: 0.6rem 1rem;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.3s ease, color 0.3s ease;
      display: block;
    }

    aside.sidebar nav a:hover,
    aside.sidebar nav a.active {
      background-color: #333;
      color: #fff;
      padding-left: 1.2rem;
    }

    /* Main content */
    main.main-content {
      margin-left: 220px; /* Igual que ancho del sidebar */
      padding: 2rem;
      flex: 1;
      background-color: #1e1e1e;
      min-height: 100vh;
    }

    /* Buscador */
    .buscador {
      text-align: center;
      margin-bottom: 2rem;
    }

    .buscador input {
      padding: 0.5rem;
      border-radius: 6px;
      border: 1px solid #444;
      background: #222;
      color: #eee;
      width: 220px;
      max-width: 100%;
    }

    .buscador button {
      padding: 0.5rem 1rem;
      border: none;
      background: #444;
      color: #fff;
      border-radius: 6px;
      cursor: pointer;
      margin-left: 0.5rem;
      transition: background-color 0.3s ease;
    }

    .buscador button:hover {
      background-color: #666;
    }

    /* Servicios Grid */
    .servicios-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 1.5rem;
    }

    .servicio-card {
      background: #2a2a2a;
      padding: 1.2rem;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.6);
      transition: transform 0.3s ease;
    }

    .servicio-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 12px rgba(0,0,0,0.8);
    }

    .servicio-card h3 {
      margin: 0 0 0.5rem;
      color: #fff;
    }

    .servicio-card p {
      margin: 0.3rem 0;
      color: #ccc;
    }

    .btn-primary {
      margin-top: 1rem;
      background-color: #555;
      color: #fff;
      padding: 0.6rem 1rem;
      border: none;
      border-radius: 20px;
      cursor: pointer;
      font-weight: 600;
      transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
      background-color: #777;
    }

    .btn-primary[disabled] {
      background-color: #333;
      color: #888;
      cursor: not-allowed;
    }

    /* Pagination */
    .pagination {
      display: flex;
      justify-content: center;
      margin-top: 2rem;
      gap: 8px;
    }

    .pagination a, .pagination span {
      padding: 0.4rem 0.8rem;
      border: 1px solid #555;
      border-radius: 6px;
      color: #eee;
      text-decoration: none;
      user-select: none;
    }

    .pagination .active {
      background: #666;
      color: #fff;
    }

    /* Toast message */
    #toast-msg {
      position: fixed;
      bottom: 30px;
      right: 30px;
      background-color: #444;
      color: white;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      z-index: 9999;
      animation: fadein 0.5s, fadeout 0.5s 3s;
    }

    @keyframes fadein {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeout {
      from { opacity: 1; }
      to   { opacity: 0; }
    }

    /* Responsive */
    @media (max-width: 768px) {
      aside.sidebar {
        position: relative;
        width: 100%;
        height: auto;
        padding: 1rem;
        box-shadow: none;
        flex-direction: row;
        justify-content: space-around;
      }

      aside.sidebar nav a {
        display: inline-block;
        padding: 0.5rem 0.75rem;
      }

      main.main-content {
        margin-left: 0;
        padding: 1rem;
      }

      .servicios-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

  <aside class="sidebar">
    <h2>Menú</h2>
    <nav>
      <a href="/panel-servicios/index.php">Inicio</a>
      <a href="/panel-servicios/pages/servicios.php" class="active">Servicios</a>
      <a href="/panel-servicios/pages/personalizados.php">Personalizados</a>
      <a href="/panel-servicios/pages/apis.php">APIs</a>
      <a href="/panel-servicios/pages/carrito.php">Carrito</a>
      <a href="/panel-servicios/pages/contacto.php">Contacto</a>
    </nav>
  </aside>

  <main class="main-content">
    <h1 style="text-align:center;">Servicios Disponibles</h1>

    <div class="buscador">
      <form method="GET">
        <input type="text" name="buscar" placeholder="Buscar servicio..." value="<?= htmlspecialchars($busqueda) ?>">
        <button type="submit">Buscar</button>
      </form>
    </div>

    <?php if ($msg): ?>
      <div id="toast-msg"><?= htmlspecialchars($msg) ?></div>
      <script>
        setTimeout(() => {
          const toast = document.getElementById('toast-msg');
          if (toast) toast.remove();
        }, 3500);
      </script>
    <?php endif; ?>

    <div class="servicios-grid">
      <?php if ($result && mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
          <div class="servicio-card">
            <h3><?= htmlspecialchars($row['nombre']) ?></h3>
            <p><?= htmlspecialchars($row['descripcion']) ?></p>
            <p><strong>Precio:</strong> $<?= number_format($row['precio'], 2) ?></p>

            <?php if (isset($_SESSION['user_id'])): ?>
              <?php if (in_array($row['id'], $serviciosAgregados)): ?>
                <button class="btn-primary" disabled>Ya en carrito</button>
              <?php else: ?>
                <form method="POST" action="/panel-servicios/form/agregar-al-carrito.php">
                  <input type="hidden" name="servicio_id" value="<?= $row['id'] ?>">
                  <button class="btn-primary" type="submit">Agregar al carrito</button>
                </form>
              <?php endif; ?>
            <?php else: ?>
              <a href="/panel-servicios/pages/login.php" class="btn-primary">Inicia sesión</a>
            <?php endif; ?>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p style="text-align:center;">No se encontraron servicios.</p>
      <?php endif; ?>
    </div>

    <div class="pagination">
      <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>&buscar=<?= urlencode($busqueda) ?>">&laquo; Anterior</a>
      <?php endif; ?>

      <?php for ($i = 1; $i <= $totalPages; $i++): ?>
        <?php if ($i == $page): ?>
          <span class="active"><?= $i ?></span>
        <?php else: ?>
          <a href="?page=<?= $i ?>&buscar=<?= urlencode($busqueda) ?>"><?= $i ?></a>
        <?php endif; ?>
      <?php endfor; ?>

      <?php if ($page < $totalPages): ?>
        <a href="?page=<?= $page + 1 ?>&buscar=<?= urlencode($busqueda) ?>">Siguiente &raquo;</a>
      <?php endif; ?>
    </div>

  </main>

</body>
</html>
