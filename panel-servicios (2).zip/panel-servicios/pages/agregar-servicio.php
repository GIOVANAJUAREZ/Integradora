<?php
session_start();
include("../includes/db.php");

// Aquí podrías verificar si es admin o usuario autorizado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Debes iniciar sesión para agregar servicios");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $descripcion = mysqli_real_escape_string($conn, $_POST['descripcion']);
    $icono = mysqli_real_escape_string($conn, $_POST['icono']); // Podrías subir imagenes o poner ruta

    if (!$nombre || !$descripcion) {
        $error = "Por favor completa todos los campos.";
    } else {
        $sql = "INSERT INTO servicios (titulo, descripcion, icono) VALUES ('$nombre', '$descripcion', '$icono')";
        if (mysqli_query($conn, $sql)) {
            $success = "Servicio agregado correctamente.";
        } else {
            $error = "Error al agregar el servicio.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Agregar Servicio</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
</head>
<body>
<?php include("../includes/header.php"); ?>

<main style="max-width: 600px; margin: 3rem auto;">
  <h1>Agregar Nuevo Servicio</h1>

  <?php if ($error): ?>
    <p style="color: red; font-weight: 700;"><?= htmlspecialchars($error) ?></p>
  <?php elseif ($success): ?>
    <p style="color: green; font-weight: 700;"><?= htmlspecialchars($success) ?></p>
  <?php endif; ?>

  <form method="POST" novalidate>
    <label for="nombre">Nombre del servicio:</label>
    <input type="text" id="nombre" name="nombre" required>

    <label for="descripcion">Descripción:</label>
    <textarea id="descripcion" name="descripcion" rows="4" required></textarea>

    <label for="icono">Icono (ruta relativa o URL):</label>
    <input type="text" id="icono" name="icono" placeholder="/panel-servicios/assets/icons/default.svg">

    <button type="submit" class="btn-primary">Agregar Servicio</button>
  </form>

  <p style="margin-top: 1.5rem;">
    <a href="/panel-servicios/pages/servicios.php" class="btn-secondary">Volver a Servicios</a>
  </p>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
