<?php include("includes/db.php"); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel de Servicios Web</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>

  <?php include("includes/header.php"); ?>

  <main>
    <!-- HERO -->
    <section class="hero-section" aria-label="Bienvenida">
      <h1>Bienvenido al Panel de Servicios Web</h1>
      <p>Elige entre nuestros servicios personalizados, integra APIs y gestiona tu carrito.</p>
      <a href="#servicios" class="btn-primary" role="button">Ver Servicios</a>
    </section>

    <!-- SERVICIOS -->
    <section id="servicios" aria-labelledby="servicios-title">
      <h2 id="servicios-title">Nuestros Servicios Destacados</h2>
      <div class="servicios-grid">
        <article class="servicio-card" aria-label="APIs Personalizadas">
          <img src="/panel-servicios/assets/icons/1.jpg" alt="Icono API" loading="lazy">
          <h3>APIs Personalizadas</h3>
          <p>Integración a medida para tus proyectos.</p>
        </article>
        <article class="servicio-card" aria-label="Hosting Seguro">
          <img src="/panel-servicios/assets/icons/2.jpg" alt="Icono Hosting" loading="lazy">
          <h3>Hosting Seguro</h3>
          <p>Servidor confiable para tus aplicaciones web.</p>
        </article>
        <article class="servicio-card" aria-label="Soporte 24/7">
          <img src="/panel-servicios/assets/icons/3.jpg" alt="Icono Soporte" loading="lazy">
          <h3>Soporte 24/7</h3>
          <p>Asistencia técnica permanente para ti.</p>
        </article>
      </div>
    </section>

    <!-- INTEGRACIÓN APIs -->
    <section id="apis" aria-labelledby="apis-title">
      <h2 id="apis-title">Integración de APIs</h2>
      <p>
        Ofrecemos conexiones seguras y rápidas para integrar APIs externas o crear las tuyas propias fácilmente desde nuestro panel.
      </p>
      <div>
        <a href="/panel-servicios/apis.php" class="btn-secondary" role="button">Ver APIs Disponibles</a>
      </div>
    </section>

    <!-- CARRITO -->
    <section id="carrito" aria-labelledby="carrito-title" style="margin-top: 4rem;">
      <h2 id="carrito-title">Tu Carrito de Compras</h2>
      <p>Gestiona tus servicios seleccionados y finaliza tu compra cuando quieras.</p>
      <div>
        <a href="/panel-servicios/carrito.php" class="btn-primary" role="button">Ir al Carrito</a>
      </div>
    </section>

    <!-- CONTACTO -->
    <section id="contacto" aria-labelledby="contacto-title">
      <h2 id="contacto-title">Contacto</h2>
      <form action="/panel-servicios/contacto.php" method="POST" novalidate>
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required placeholder="Tu nombre completo">

        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com">

        <label for="mensaje">Mensaje:</label>
        <textarea id="mensaje" name="mensaje" rows="5" required placeholder="Escribe tu mensaje aquí..."></textarea>

        <button type="submit">Enviar</button>
      </form>
    </section>
  </main>

  <?php include("includes/footer.php"); ?>

</body>
</html>
