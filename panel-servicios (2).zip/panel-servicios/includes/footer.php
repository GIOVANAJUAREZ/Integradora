    </main>
    <footer>
        <p>&copy; 2025 Panel de Servicios Web. Todos los derechos reservados.</p>
    </footer>
    <script src="/assets/js/scripts.js"></script>
</body>
</html>
