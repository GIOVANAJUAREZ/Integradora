<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);
$delete = "DELETE FROM carrito WHERE user_id = $user_id";

if (mysqli_query($conn, $delete)) {
    header("Location: ../pages/carrito.php?msg=¡Compra finalizada! Gracias por tu preferencia.");
} else {
    header("Location: ../pages/carrito.php?msg=Ocurrió un error al finalizar tu compra.");
}
