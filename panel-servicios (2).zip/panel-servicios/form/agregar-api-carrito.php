<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para agregar al carrito");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_SESSION['user_id']);

    if (!isset($_POST['api_id']) || !is_numeric($_POST['api_id']) || intval($_POST['api_id']) <= 0) {
        header("Location: ../pages/apis.php?msg=ID de API inválido");
        exit();
    }

    $api_id = intval($_POST['api_id']);

    // Validar que la API exista
    $checkAPI = mysqli_query($conn, "SELECT id FROM apis WHERE id = $api_id");
    if (!$checkAPI || mysqli_num_rows($checkAPI) === 0) {
        header("Location: ../pages/apis.php?msg=API no encontrada");
        exit();
    }

    // Validar que no esté ya en el carrito
    $checkExist = mysqli_query($conn, "SELECT id FROM carrito WHERE user_id = $user_id AND api_id = $api_id");
    if ($checkExist && mysqli_num_rows($checkExist) > 0) {
        header("Location: ../pages/apis.php?msg=Esta API ya está en tu carrito");
        exit();
    }

    // Insertar en carrito (servicio_id = NULL)
    $insert = mysqli_query($conn, "INSERT INTO carrito (user_id, servicio_id, api_id) VALUES ($user_id, NULL, $api_id)");

    if ($insert) {
        header("Location: ../pages/apis.php?msg=API agregada al carrito");
        exit();
    } else {
        // Error de inserción, puede ser por duplicados o DB
        header("Location: ../pages/apis.php?msg=Error al agregar la API");
        exit();
    }
} else {
    header("Location: ../pages/apis.php?msg=Solicitud inválida");
    exit();
}
