<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para agregar servicios al carrito");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_SESSION['user_id']);
    $servicio_id = intval($_POST['servicio_id']);
    $tipo = $_POST['tipo'] ?? 'normal'; // puede ser 'normal' o 'personalizado'

    // Tabla y redirección según tipo
    if ($tipo === 'personalizado') {
        $tabla = 'personalizados';
        $redireccion = '../pages/personalizados.php';
    } else {
        $tabla = 'servicios';
        $redireccion = '../pages/servicios.php';
    }

    // Verificar si el servicio existe
    $checkServicio = mysqli_query($conn, "SELECT id FROM $tabla WHERE id = $servicio_id");
    if (!$checkServicio || mysqli_num_rows($checkServicio) === 0) {
        header("Location: $redireccion?msg=Servicio no encontrado");
        exit();
    }

    // Verificar si ya está en el carrito
    $checkCarrito = mysqli_query($conn, "SELECT id FROM carrito WHERE user_id = $user_id AND servicio_id = $servicio_id");
    if ($checkCarrito && mysqli_num_rows($checkCarrito) > 0) {
        header("Location: $redireccion?msg=Este servicio ya está en tu carrito");
        exit();
    }

    // Insertar en carrito
    $insert = "INSERT INTO carrito (user_id, servicio_id) VALUES ($user_id, $servicio_id)";
    if (mysqli_query($conn, $insert)) {
        header("Location: $redireccion?msg=Servicio agregado al carrito");
    } else {
        header("Location: $redireccion?msg=Error al agregar el servicio");
    }
} else {
    header("Location: ../pages/servicios.php");
}
