<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['carrito']) || count($_SESSION['carrito']) === 0) {
    header("Location: carrito.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Aquí procesarías el pago o guardas la compra en BD, por simplicidad:
    // Luego limpia carrito:
    unset($_SESSION['carrito']);
    echo "<script>alert('Compra realizada con éxito. ¡Gracias!'); window.location.href = 'index.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Finalizar Compra</title>
    <link rel="stylesheet" href="/panel-servicios/assets/css/style.css">
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <section class="hero-section">
    <h1>Finalizar Compra</h1>
    <p>Revisa tus servicios y confirma tu compra.</p>
  </section>

  <section style="max-width:700px; margin: 2rem auto;">
    <h2>Resumen del carrito</h2>
    <div class="servicios-grid">
      <?php foreach ($_SESSION['carrito'] as $item): ?>
        <article class="servicio-card">
          <img src="/panel-servicios/assets/icons/project.svg" alt="Servicio" loading="lazy">
          <h3><?= htmlspecialchars($item['nombre']) ?></h3>
          <p><?= htmlspecialchars($item['descripcion']) ?></p>
        </article>
      <?php endforeach; ?>
    </div>

    <form method="POST" style="text-align:center; margin-top:2rem;">
      <button type="submit" class="btn-primary">Confirmar compra</button>
    </form>
  </section>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
