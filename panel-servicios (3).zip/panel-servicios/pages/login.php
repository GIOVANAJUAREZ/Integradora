<?php
session_start();
include("../includes/db.php");

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = mysqli_real_escape_string($conn, $_POST['usuario']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['usuario'] = $row['usuario'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Usuario o contraseña incorrectos.";
        }
    } else {
        $error = "Usuario o contraseña incorrectos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
</head>
<body>
<?php include("../includes/header.php"); ?>

<main style="max-width: 400px; margin: 3rem auto;">
  <h1>Iniciar Sesión</h1>
  <?php if ($error): ?>
    <p style="color: red; font-weight: 700;"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>
  <form method="POST" novalidate>
    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario" required>

    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>

    <button type="submit" class="btn-primary">Entrar</button>
  </form>
  <p>¿No tienes cuenta? <a href="registro.php">Regístrate</a></p>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
