<?php
session_start();
include("../includes/db.php");

$msg = $_GET['msg'] ?? '';

// Paginación
$itemsPorPagina = 6;
$pagina = isset($_GET['pagina']) && is_numeric($_GET['pagina']) ? intval($_GET['pagina']) : 1;
if ($pagina < 1) $pagina = 1;

$resultCount = mysqli_query($conn, "SELECT COUNT(*) AS total FROM apis");
$totalApis = $resultCount ? intval(mysqli_fetch_assoc($resultCount)['total']) : 0;
$totalPaginas = ceil($totalApis / $itemsPorPagina);
$offset = ($pagina - 1) * $itemsPorPagina;

$user_id = $_SESSION['user_id'] ?? 0;
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>APIs Disponibles</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    /* Estilos base */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #121212;
      color: #eee;
      margin: 0;
      padding: 0;
      display: flex;
      min-height: 100vh;
    }
    aside.sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px; height: 100vh;
      background-color: #000;
      padding: 2rem 1rem;
      box-shadow: 2px 0 8px rgba(255,255,255,0.1);
      z-index: 1000;
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }
    aside.sidebar h2 {
      color: #eee;
      text-align: center;
      margin-bottom: 2rem;
      font-weight: 700;
      font-size: 1.5rem;
    }
    aside.sidebar nav a {
      color: #bbb;
      text-decoration: none;
      padding: 0.6rem 1rem;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.3s ease, color 0.3s ease;
      display: block;
    }
    aside.sidebar nav a:hover,
    aside.sidebar nav a.active {
      background-color: #eee;
      color: #000;
      padding-left: 1.2rem;
    }
    main {
      flex: 1;
      margin-left: 220px;
      padding: 2rem;
      max-width: 100%;
    }
    .hero-section {
      text-align: center;
      margin-bottom: 2rem;
      color: #eee;
    }
    .apis-grid {
      display: flex;
      flex-wrap: wrap;
      gap: 2rem;
      justify-content: center;
    }
    .api-card {
      background-color: #1e1e1e;
      border: 1px solid #333;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(255,255,255,0.05);
      width: 320px;
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      color: #eee;
      transition: box-shadow 0.3s ease;
    }
    .api-card:hover {
      box-shadow: 0 8px 16px rgba(255,255,255,0.15);
    }
    .api-card h3 {
      font-size: 1.5rem;
      margin-bottom: 0.6rem;
      color: #fff;
    }
    .api-card p {
      flex-grow: 1;
      font-size: 1rem;
      margin-bottom: 1rem;
      color: #ccc;
    }
    .api-card .precio {
      font-weight: 700;
      color: #bbb;
      margin-bottom: 1rem;
    }
    .api-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
    }
    .api-buttons a,
    .api-buttons button {
      flex: 1;
      padding: 0.6rem 1rem;
      border-radius: 25px;
      font-weight: 700;
      cursor: pointer;
      border: none;
      font-size: 1rem;
      transition: background-color 0.3s ease;
      text-align: center;
      text-decoration: none;
      user-select: none;
      color: #eee;
      background-color: #444;
    }
    .api-buttons a:hover,
    .api-buttons button:hover:not(:disabled) {
      background-color: #666;
    }
    .api-buttons button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }
    .toast {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #444;
      color: #eee;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.7);
      font-weight: 600;
      z-index: 9999;
      animation: fadein 0.4s, fadeout 0.5s 3s forwards;
    }
    @keyframes fadein {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeout {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    .paginacion {
      margin-top: 2rem;
      text-align: center;
      user-select: none;
    }
    .paginacion a, .paginacion span {
      display: inline-block;
      margin: 0 0.3rem;
      padding: 0.5rem 0.8rem;
      color: #eee;
      background-color: #333;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    .paginacion a:hover {
      background-color: #666;
    }
    .paginacion span {
      background-color: #007BFF;
      cursor: default;
    }
    @media (max-width: 768px) {
      aside.sidebar {
        position: relative;
        width: 100%;
        height: auto;
        flex-direction: row;
        padding: 1rem;
        box-shadow: none;
      }
      aside.sidebar h2 {
        display: none;
      }
      aside.sidebar nav {
        display: flex;
        gap: 1rem;
        width: 100%;
        justify-content: center;
      }
      aside.sidebar nav a {
        padding: 0.5rem;
        font-size: 0.9rem;
      }
      main {
        margin-left: 0;
        padding: 1rem;
      }
      .apis-grid {
        flex-direction: column;
        align-items: center;
      }
      .api-card {
        width: 90%;
      }
    }
  </style>
</head>
<body>

  <aside class="sidebar">
    <h2>Menú</h2>
    <nav>
      <a href="/panel-servicios/index.php">Inicio</a>
      <a href="/panel-servicios/pages/servicios.php">Servicios</a>
      <a href="/panel-servicios/pages/personalizados.php">Personalizados</a>
      <a href="/panel-servicios/pages/apis.php" class="active">APIs</a>
      <a href="/panel-servicios/pages/carrito.php">Carrito</a>
      <a href="/panel-servicios/pages/contacto.php">Contacto</a>
    </nav>
  </aside>

  <main>
    <section class="hero-section">
      <h1>APIs Disponibles</h1>
      <p>Explora e integra APIs para potenciar tus proyectos.</p>
    </section>

    <?php if ($msg): ?>
      <div class="toast"><?= htmlspecialchars($msg) ?></div>
      <script>
        setTimeout(() => {
          const toast = document.querySelector('.toast');
          if (toast) toast.remove();
        }, 3500);
      </script>
    <?php endif; ?>

    <section class="apis-grid">
      <?php
      $query = "SELECT * FROM apis ORDER BY nombre ASC LIMIT $itemsPorPagina OFFSET $offset";
      $result = mysqli_query($conn, $query);

      if ($result && mysqli_num_rows($result) > 0):
        while ($api = mysqli_fetch_assoc($result)):
          $id = intval($api['id']);
          $nombre = $api['nombre'];
          $descripcion = $api['descripcion'];
          $url = $api['url'];
          $precio = isset($api['precio']) ? number_format($api['precio'], 2) : '0.00';

          $ya_en_carrito = false;
          if ($user_id) {
            $check = mysqli_query($conn, "SELECT id FROM carrito WHERE user_id = $user_id AND item_id = $id AND tipo = 'api'");
            $ya_en_carrito = $check && mysqli_num_rows($check) > 0;
          }

          if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
          }
      ?>
      <article class="api-card">
        <h3><?= htmlspecialchars($nombre) ?></h3>
        <p><?= htmlspecialchars($descripcion) ?></p>
        <p class="precio">Precio: $<?= $precio ?></p>
        <div class="api-buttons">
          <a href="<?= htmlspecialchars($url) ?>" target="_blank" rel="noopener noreferrer" class="btn-doc">Documentación</a>

          <?php if ($user_id): ?>
            <?php if ($ya_en_carrito): ?>
              <button class="btn-agregar" disabled>Ya en carrito</button>
            <?php else: ?>
              <form method="POST" action="/panel-servicios/form/agregar-api-carrito.php" style="margin:0;">
                <input type="hidden" name="api_id" value="<?= $id ?>">
                <button type="submit" class="btn-agregar" aria-label="Agregar API <?= htmlspecialchars($nombre) ?> al carrito">Agregar al carrito</button>
              </form>
            <?php endif; ?>
          <?php else: ?>
            <a href="/panel-servicios/pages/login.php" class="btn-agregar">Inicia sesión</a>
          <?php endif; ?>
        </div>
      </article>
      <?php
        endwhile;
      else:
      ?>
      <p style="text-align:center;">No hay APIs disponibles.</p>
      <?php endif; ?>
    </section>

    <?php if ($totalPaginas > 1): ?>
      <nav class="paginacion" aria-label="Paginación APIs">
        <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
          <?php if ($i === $pagina): ?>
            <span><?= $i ?></span>
          <?php else: ?>
            <a href="?pagina=<?= $i ?>"><?= $i ?></a>
          <?php endif; ?>
        <?php endfor; ?>
      </nav>
    <?php endif; ?>

  </main>

</body>
</html>
