<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include("../includes/db.php");

$user_id = $_SESSION['user_id'];
$usuario = $_SESSION['usuario'];

// Obtener APIs contratadas del usuario
$query = "SELECT apis.nombre, apis.descripcion, apis.url 
          FROM contratos_api 
          JOIN apis ON contratos_api.api_id = apis.id 
          WHERE contratos_api.user_id = $user_id";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Panel de Usuario</title>
  <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
  <style>
    .apis-list {
      max-width: 700px;
      margin: 2rem auto;
      background: #fff8f2;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 6px 12px rgba(92,75,58,0.1);
      color: #5C4B3A;
    }
    .apis-list h2 {
      text-align: center;
      color: #B79972;
    }
    .api-item {
      border-bottom: 1px solid #B79972;
      padding: 1rem 0;
    }
    .api-item:last-child {
      border: none;
    }
    .api-item a {
      color: #926F49;
      text-decoration: none;
      font-weight: 700;
    }
  </style>
</head>
<body>
<?php include("../includes/header.php"); ?>

<main>
  <section class="hero-section" aria-label="Panel de usuario">
    <h1>Hola, <?= htmlspecialchars($usuario) ?></h1>
    <p>Estas son las APIs que has contratado:</p>
  </section>

  <section class="apis-list" aria-live="polite">
    <?php if ($result && mysqli_num_rows($result) > 0): ?>
      <?php while ($api = mysqli_fetch_assoc($result)): ?>
        <div class="api-item">
          <h3><?= htmlspecialchars($api['nombre']) ?></h3>
          <p><?= htmlspecialchars($api['descripcion']) ?></p>
          <a href="<?= htmlspecialchars($api['url']) ?>" target="_blank" rel="noopener">Ver documentación</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center;">No has contratado ninguna API aún.</p>
    <?php endif; ?>
  </section>

  <p style="text-align:center; margin-top:2rem;">
    <a href="logout.php" class="btn-secondary">Cerrar sesión</a>
  </p>
</main>

<?php include("../includes/footer.php"); ?>
</body>
</html>
