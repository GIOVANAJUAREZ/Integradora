<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: /panel-servicios/pages/login.php?msg=Debes iniciar sesión para ver tu carrito");
    exit();
}

$user_id = intval($_SESSION['user_id']);

// Obtenemos los productos en carrito para este usuario
$query = "SELECT * FROM carrito WHERE user_id = $user_id";
$result = mysqli_query($conn, $query);

$items = [];
$total = 0.0;

while ($row = mysqli_fetch_assoc($result)) {
    $item_id = intval($row['item_id']);
    $tipo = $row['tipo'];

    $detalle = null;

    switch ($tipo) {
        case 'servicio':
            $res = mysqli_query($conn, "SELECT nombre, descripcion, precio FROM servicios WHERE id = $item_id");
            $detalle = mysqli_fetch_assoc($res);
            break;
        case 'personalizado':
            $res = mysqli_query($conn, "SELECT nombre, descripcion, precio FROM personalizados WHERE id = $item_id");
            $detalle = mysqli_fetch_assoc($res);
            break;
        case 'api':
            $res = mysqli_query($conn, "SELECT nombre, descripcion, precio, url FROM apis WHERE id = $item_id");
            $detalle = mysqli_fetch_assoc($res);
            break;
    }

    if ($detalle) {
        $items[] = [
            'id' => $item_id,
            'tipo' => $tipo,
            'nombre' => $detalle['nombre'],
            'descripcion' => $detalle['descripcion'],
            'precio' => floatval($detalle['precio']),
            'url' => $detalle['url'] ?? null,
        ];
        $total += floatval($detalle['precio']);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Carrito de Compras</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #121212;
      color: #eee;
      margin: 0;
      padding: 0;
      min-height: 100vh;
    }
    aside.sidebar {
      position: fixed;
      top: 0; left: 0;
      width: 220px; height: 100vh;
      background-color: #1a1a1a;
      padding: 2rem 1rem;
      box-shadow: 2px 0 8px rgba(0,0,0,0.8);
      z-index: 1000;
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }
    aside.sidebar h2 {
      color: #fff;
      text-align: center;
      margin-bottom: 2rem;
      font-weight: 700;
      font-size: 1.5rem;
    }
    aside.sidebar nav a {
      color: #bbb;
      text-decoration: none;
      padding: 0.6rem 1rem;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.3s ease, color 0.3s ease;
      display: block;
    }
    aside.sidebar nav a:hover,
    aside.sidebar nav a.active {
      background-color: #333;
      color: #fff;
      padding-left: 1.2rem;
    }
    main {
      margin-left: 220px;
      padding: 2rem;
      background-color: #1e1e1e;
      min-height: 100vh;
    }
    h1 {
      text-align: center;
      margin-bottom: 2rem;
    }
    .carrito-list {
      max-width: 900px;
      margin: 0 auto;
      border-collapse: collapse;
      width: 100%;
    }
    .carrito-list th, .carrito-list td {
      border: 1px solid #444;
      padding: 0.8rem 1rem;
      text-align: left;
    }
    .carrito-list th {
      background-color: #333;
      color: #eee;
    }
    .carrito-list tbody tr:hover {
      background-color: #2a2a2a;
    }
    .precio {
      text-align: right;
      font-weight: 700;
    }
    .total {
      margin-top: 1rem;
      text-align: right;
      font-size: 1.3rem;
      font-weight: 700;
      color: #fff;
    }
    a.btn-eliminar {
      color: #f44336;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
      transition: color 0.3s ease;
    }
    a.btn-eliminar:hover {
      color: #ff7961;
    }
    a.btn-detalle {
      color: #2196f3;
      text-decoration: none;
      font-weight: 600;
    }
    a.btn-detalle:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <aside class="sidebar">
    <h2>Menú</h2>
    <nav>
      <a href="/panel-servicios/index.php">Inicio</a>
      <a href="/panel-servicios/pages/servicios.php">Servicios</a>
      <a href="/panel-servicios/pages/personalizados.php">Personalizados</a>
      <a href="/panel-servicios/pages/apis.php">APIs</a>
      <a href="/panel-servicios/pages/carrito.php" class="active">Carrito</a>
      <a href="/panel-servicios/pages/contacto.php">Contacto</a>
    </nav>
  </aside>

  <main>
    <h1>Tu Carrito de Compras</h1>

    <?php if (empty($items)): ?>
      <p style="text-align:center;">Tu carrito está vacío.</p>
    <?php else: ?>
      <table class="carrito-list" aria-label="Lista de productos en carrito">
        <thead>
          <tr>
            <th>Tipo</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td><?= htmlspecialchars(ucfirst($item['tipo'])) ?></td>
              <td>
                <?= htmlspecialchars($item['nombre']) ?>
                <?php if ($item['tipo'] === 'api' && $item['url']): ?>
                  <br><a href="<?= htmlspecialchars($item['url']) ?>" target="_blank" class="btn-detalle" rel="noopener noreferrer">Ver documentación</a>
                <?php endif; ?>
              <td><?= htmlspecialchars($item['descripcion']) ?></td>
              <td class="precio">$<?= number_format($item['precio'], 2) ?></td>
              <td>
                <a href="/panel-servicios/form/eliminar-del-carrito.php?item_id=<?= $item['id'] ?>&tipo=<?= urlencode($item['tipo']) ?>" 
                   class="btn-eliminar" 
                   onclick="return confirm('¿Seguro que quieres eliminar este producto del carrito?');"
                   aria-label="Eliminar <?= htmlspecialchars($item['nombre']) ?> del carrito">
                   Eliminar
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>

      <div class="total">
        Total a pagar: $<?= number_format($total, 2) ?>
      </div>
    <?php endif; ?>
  </main>

</body>
</html>

