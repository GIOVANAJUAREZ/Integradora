<?php
session_start();
include("../includes/db.php");
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    if (!$usuario || !$email || !$password || !$password2) {
        $error = 'Todos los campos son obligatorios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Email no válido.';
    } elseif ($password !== $password2) {
        $error = 'Las contraseñas no coinciden.';
    } else {
        // Revisar si usuario o email existe
        $usuario_esc = mysqli_real_escape_string($conn, $usuario);
        $email_esc = mysqli_real_escape_string($conn, $email);
        $check = "SELECT * FROM usuarios WHERE usuario='$usuario_esc' OR email='$email_esc'";
        $res = mysqli_query($conn, $check);
        if ($res && mysqli_num_rows($res) > 0) {
            $error = 'El usuario o email ya está registrado.';
        } else {
            // Insertar nuevo usuario
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $insert = "INSERT INTO usuarios (usuario, email, password) VALUES ('$usuario_esc', '$email_esc', '$hash')";
            if (mysqli_query($conn, $insert)) {
                $_SESSION['user_id'] = mysqli_insert_id($conn);
                $_SESSION['usuario'] = $usuario;
                header("Location: ../index.php");
                exit();
            } else {
                $error = 'Error al registrar usuario.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Registro</title>
    <link rel="stylesheet" href="/panel-servicios/assets/css/style.css" />
    <style>
        form { max-width: 400px; margin: 2rem auto; background: #fff8f2; padding: 2rem; border-radius: 12px; box-shadow: 0 6px 12px rgba(92,75,58,0.1); }
        label, input { display: block; width: 100%; margin-bottom: 1rem; }
        input { padding: 0.7rem; border: 1.5px solid #D1C1B3; border-radius: 8px; color: #5C4B3A; font-size: 1rem; }
        input:focus { border-color: #B79972; outline: none; }
        button { background-color: #B79972; border: none; padding: 0.85rem; border-radius: 30px; color: #FAF5F0; font-weight: 700; cursor: pointer; width: 100%; font-size: 1.1rem; }
        button:hover { background-color: #926F49; }
        .error { color: red; margin-bottom: 1rem; text-align: center; }
    </style>
</head>
<body>
<?php include("../includes/header.php"); ?>

<form method="POST" novalidate>
    <h2 style="text-align:center; margin-bottom: 1rem;">Registro de Usuario</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario" required autocomplete="off" value="<?= htmlspecialchars($_POST['usuario'] ?? '') ?>">

    <label for="email">Correo Electrónico:</label>
    <input type="email" id="email" name="email" required autocomplete="off" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">

    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>

    <label for="password2">Confirmar Contraseña:</label>
    <input type="password" id="password2" name="password2" required>

    <button type="submit">Registrarse</button>

    <p style="text-align:center; margin-top:1rem;">¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
</form>

<?php include("../includes/footer.php"); ?>
</body>
</html>
