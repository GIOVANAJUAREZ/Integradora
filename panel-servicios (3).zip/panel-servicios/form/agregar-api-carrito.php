<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: /panel-servicios/pages/login.php?msg=Debes iniciar sesión para agregar al carrito");
    exit();
}

$user_id = intval($_SESSION['user_id']);
$api_id = isset($_POST['api_id']) ? intval($_POST['api_id']) : 0;

if ($api_id <= 0) {
    header("Location: /panel-servicios/pages/apis.php?msg=ID de API inválido");
    exit();
}

// Verificar si ya está en carrito para evitar duplicados
$check = mysqli_query($conn, "SELECT id FROM carrito WHERE user_id = $user_id AND item_id = $api_id AND tipo = 'api'");
if (mysqli_num_rows($check) > 0) {
    header("Location: /panel-servicios/pages/apis.php?msg=API ya está en tu carrito");
    exit();
}

// Insertar en carrito
$query = "INSERT INTO carrito (user_id, item_id, tipo) VALUES ($user_id, $api_id, 'api')";
if (mysqli_query($conn, $query)) {
    header("Location: /panel-servicios/pages/apis.php?msg=API agregada al carrito");
    exit();
} else {
    header("Location: /panel-servicios/pages/apis.php?msg=Error al agregar la API");
    exit();
}
