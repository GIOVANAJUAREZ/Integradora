<?php
session_start();
include("../includes/db.php");

// Verificar que usuario esté logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para contratar APIs");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $api_id = intval($_POST['api_id']);
    $user_id = intval($_SESSION['user_id']);

    // Validar que la API exista
$query = "SELECT apis.nombre, contratos_api.fecha_contrato FROM contratos_api JOIN apis ON contratos_api.api_id = apis.id";
    $result = mysqli_query($conn, $query);
    if (!$result || mysqli_num_rows($result) == 0) {
        header("Location: ../pages/apis.php?msg=API no encontrada");
        exit();
    }


    // Verificar si ya la tiene contratada
    $check = "SELECT * FROM contratos_api WHERE api_id = $api_id AND user_id = $user_id";
    $resCheck = mysqli_query($conn, $check);
    if ($resCheck && mysqli_num_rows($resCheck) > 0) {
        header("Location: ../pages/apis.php?msg=Ya tienes contratada esta API");
        exit();
    }

    // Insertar el contrato
    $insert = "INSERT INTO contratos_api (api_id, user_id, fecha) VALUES ($api_id, $user_id, NOW())";
    if (mysqli_query($conn, $insert)) {
        header("Location: ../pages/apis.php?msg=API contratada exitosamente");
    } else {
        header("Location: ../pages/apis.php?msg=Error al contratar la API");
    }
} else {
    header("Location: ../pages/apis.php");
}
