<?php
session_start();
include("../includes/db.php");

// Redirigir si no ha iniciado sesión
if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para agregar productos al carrito");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_SESSION['user_id']);
    $item_id = intval($_POST['servicio_id']); // Puede ser id de servicio, personalizado o api
    $tipo = $_POST['tipo'] ?? 'servicio'; // Valores válidos: servicio, personalizado, api

    // Validar tipo
    $tipos_validos = ['servicio', 'personalizado', 'api'];
    if (!in_array($tipo, $tipos_validos)) {
        header("Location: ../pages/servicios.php?msg=Tipo de producto no válido");
        exit();
    }

    // Determinar tabla y redirección según el tipo
    switch ($tipo) {
        case 'personalizado':
            $tabla = 'personalizados';
            $redireccion = '../pages/personalizados.php';
            break;
        case 'api':
            $tabla = 'apis';
            $redireccion = '../pages/apis.php';
            break;
        default:
            $tabla = 'servicios';
            $redireccion = '../pages/servicios.php';
            break;
    }

    // Verificar que el producto existe en la tabla correspondiente
    $existe = mysqli_query($conn, "SELECT id FROM $tabla WHERE id = $item_id");
    if (!$existe || mysqli_num_rows($existe) === 0) {
        header("Location: $redireccion?msg=El producto no existe");
        exit();
    }

    // Verificar si ya está en el carrito
    $existeCarrito = mysqli_query($conn, "SELECT id FROM carrito WHERE user_id = $user_id AND tipo = '$tipo' AND item_id = $item_id");
    if ($existeCarrito && mysqli_num_rows($existeCarrito) > 0) {
        header("Location: $redireccion?msg=Este producto ya está en tu carrito");
        exit();
    }

    // Insertar en el carrito
    $insert = mysqli_query($conn, "INSERT INTO carrito (user_id, tipo, item_id) VALUES ($user_id, '$tipo', $item_id)");

    if ($insert) {
        header("Location: $redireccion?msg=Producto agregado al carrito");
    } else {
        header("Location: $redireccion?msg=Error al agregar el producto");
    }

} else {
    // Si no es POST, redirige a servicios
    header("Location: ../pages/servicios.php");
    exit();
}
?>
