<?php
session_start();
include("../includes/db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../pages/login.php?msg=Debes iniciar sesión para eliminar servicios del carrito");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_SESSION['user_id']);
    $servicio_id = intval($_POST['servicio_id']);

    // Verificar que el servicio esté en el carrito del usuario
    $check = "SELECT * FROM carrito WHERE user_id = $user_id AND servicio_id = $servicio_id";
    $resCheck = mysqli_query($conn, $check);

    if ($resCheck && mysqli_num_rows($resCheck) > 0) {
        // Eliminar el servicio del carrito
        $delete = "DELETE FROM carrito WHERE user_id = $user_id AND servicio_id = $servicio_id";
        if (mysqli_query($conn, $delete)) {
            header("Location: ../pages/carrito.php?msg=Servicio eliminado del carrito");
            exit();
        } else {
            header("Location: ../pages/carrito.php?msg=Error al eliminar el servicio");
            exit();
        }
    } else {
        header("Location: ../pages/carrito.php?msg=El servicio no está en tu carrito");
        exit();
    }
} else {
    header("Location: ../pages/carrito.php");
    exit();
}
